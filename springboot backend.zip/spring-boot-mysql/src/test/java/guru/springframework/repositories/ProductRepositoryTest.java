package guru.springframework.repositories;

public class ProductRepositoryTest {
}