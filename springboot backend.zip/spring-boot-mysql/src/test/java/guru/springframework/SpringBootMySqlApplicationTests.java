package guru.springframework;


public class SpringBootMySqlApplicationTests {


}
