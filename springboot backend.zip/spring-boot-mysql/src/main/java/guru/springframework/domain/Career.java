package guru.springframework.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Career {
	@Id
    @GeneratedValue
    private Long _id;
	
	private String firstName;
	private String lastName;
	private String company;
	private String email;
	private String areaCode;
	private String phone;
	private String gender;
	private String beginner;
	
	public Long getId() {
		return _id;
	}
	public void setId(Long _id) {
		this._id = _id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBeginner() {
		return beginner;
	}
	public void setBeginner(String beginner) {
		this.beginner = beginner;
	}
	
	@Override
	public String toString() {
		return "Career [firstName=" + firstName + ", lastName=" + lastName + ", company=" + company
				+ ", email=" + email + ", areaCode=" + areaCode + ", phone=" + phone + ", gender=" + gender
				+ ", beginner=" + beginner + "]";
	}

}
