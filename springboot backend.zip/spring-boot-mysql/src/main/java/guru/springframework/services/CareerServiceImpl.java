package guru.springframework.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import guru.springframework.converters.ProductFormToProduct;
import guru.springframework.domain.Career;
import guru.springframework.domain.Product;
import guru.springframework.repositories.CareertRepository;
import guru.springframework.repositories.ProductRepository;

/**
 * Created by jt on 1/10/17.
 */
@Service
public class CareerServiceImpl implements CareerService {

    private ProductRepository productRepository;
    private ProductFormToProduct productFormToProduct;
    
    private CareertRepository careerRepository;
    

    @Autowired
    public CareerServiceImpl(CareertRepository CareerRepository, ProductFormToProduct productFormToProduct) {
        this.careerRepository = careerRepository;
       // this.productFormToProduct = productFormToProduct;
    }


    @Override
    public List<Product> listAll() {
        List<Product> products = new ArrayList<>();
        productRepository.findAll().forEach(products::add); //fun with Java 8
        return products;
    }

    @Override
    public Product getById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    //@Override
    public Product saveOrUpdate(Product product) {
        productRepository.save(product);
        return product;
    }

    @Override
    public void delete(Long id) {
        productRepository.deleteById(id);

    }

    @Override
    public Career saveOrUpdateCareerForm(Career productForm) {
		/*
		 * Career savedCareer = saveOrUpdate(careerRepository.convert(productForm));
		 * 
		 * System.out.println("Saved Career Id: " + savedCareer.getId()); return
		 * savedCareer;
		 */
    	return new Career();
    }
}
