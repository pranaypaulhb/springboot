<?php
$server_name="localhost";
$username="root";
$password="";
$database_name="database1";

$conn=mysqli_connect($server_name,$username,$password,$database_name);
//now check the connection
if(!$conn)
{
	die("Connection Failed:" . mysqli_connect_error());

}

if(isset($_POST['save']))
{	
	 $Admin_Id = $_POST['Admin_Id'];
	 $Admin_password = $_POST['Admin_password'];

	 $sql_query = "INSERT INTO entry_details (Admin_Id,Admin_password)
	 VALUES ('$server_name,$username,$password,$database_name')";

	 if (mysqli_query($conn, $sql_query)) 
	 {
		echo "New Details Entry inserted successfully !";
	 } 
	 else
     {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>