<?php
$firstName = $_POST['firstName'];
$lastName = $_POST['lasttName'];
$company = $_POST['company'];
$email = $_POST['email'];
$area_code = $_POST['area_code'];
$phone = $_POST['phone'];


$sql = "INSERT INTO `tbl_contact` (`Id`, `fldname`, `fldEmail`, `fldPhone`, `fldMessage`) VALUES ( '$firstName', '$lastName', '$company', '$email','$area_code','phone');"

$rs = mysqli_query($con, $sql);


if($rs)
{
	echo "Contact Records Inserted";
}




?>