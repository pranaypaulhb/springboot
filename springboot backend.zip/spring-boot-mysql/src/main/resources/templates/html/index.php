<?php

$firstName = $_POST['firstName'];
$lastName = $_POST['lasttName'];
$company = $_POST['company'];
$email = $_POST['email'];
$area_code = $_POST['area_code'];
$phone = $_POST['phone'];

//data base connection 
$conn= new mysqli('localhost','root','','kate');
if ($conn->connect_error){
	die('connection faild :' .$conn->connect_error);
}else{
	$stmt=$conn->prepare("insert into registation(firstName,lastName,company,email,area_code,phone)values(?,?,?,?,?,?,?)")
	$stmt->blind_param("ssssiii",$firstName,$lastName,$company,$email,$area_code,$phone);
	$stmp->execute();
	echo"registation succesfully...";
	$stmt->close();
	$conn->close();
}


?>